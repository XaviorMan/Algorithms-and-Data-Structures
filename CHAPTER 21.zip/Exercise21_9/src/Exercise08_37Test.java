import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class Exercise08_37Test {
    
    @Test
    public void testScore100Percent() {
        double expectedScore = 100.0;
        double actualScore = calculateTestScore(50, 50);
        assertEquals(expectedScore, actualScore, 0.001);
    }

    @Test
    public void testScore80Percent() {
        double expectedScore = 80.0;
        double actualScore = calculateTestScore(40, 50);
        assertEquals(expectedScore, actualScore, 0.001);
    }

    @Test
    public void testScore60Percent() {
        double expectedScore = 60.0;
        double actualScore = calculateTestScore(30, 50);
        assertEquals(expectedScore, actualScore, 0.001);
    }

    @Test
    public void testScore0Percent() {
        double expectedScore = 0.0;
        double actualScore = calculateTestScore(0, 50);
        assertEquals(expectedScore, actualScore, 0.001);
    }

    private double calculateTestScore(int correctCount, int totalQuestions) {
        double score = (double) correctCount / totalQuestions * 100;
        return score;
    }
}
