import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exercise08_37 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Choose an option:");
        System.out.println("1. Find out state capital");
        System.out.println("2. Take a test on the state capitals");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (choice == 1) {
            findStateCapital();
        } else if (choice == 2) {
            takeStateCapitalsTest();
        } else {
            System.out.println("Invalid choice.");
        }
        
        scanner.close();
    }

    private static void findStateCapital() {
        Map<String, String> stateCapitalMap = createStateCapitalMap();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a state: ");
        String state = scanner.nextLine().trim();

        if (stateCapitalMap.containsKey(state)) {
            String capital = stateCapitalMap.get(state);
            System.out.println("The capital of " + state + " is " + capital);
        } else {
            System.out.println("State not found.");
        }
        
        scanner.close();
    }

    private static void takeStateCapitalsTest() {
        Map<String, String> stateCapitalMap = createStateCapitalMap();
        Scanner scanner = new Scanner(System.in);
        int totalQuestions = stateCapitalMap.size();
        int correctCount = 0;

        for (Map.Entry<String, String> entry : stateCapitalMap.entrySet()) {
            String state = entry.getKey();
            String capital = entry.getValue();

            System.out.print("What is the capital of " + state + "? ");
            String userCapital = scanner.nextLine().trim();

            if (userCapital.equalsIgnoreCase(capital)) {
                System.out.println("Your answer is correct");
                correctCount++;
            } else {
                System.out.println("The correct answer should be " + capital);
            }
        }

        double score = (double) correctCount / totalQuestions * 100;
        System.out.println("Test score: " + score + "%");
        
        scanner.close();
    }

    private static Map<String, String> createStateCapitalMap() {
        Map<String, String> stateCapitalMap = new HashMap<>();
        stateCapitalMap.put("Alabama", "Montgomery");
        stateCapitalMap.put("Alaska", "Juneau");
        stateCapitalMap.put("Arizona", "Phoenix");
        stateCapitalMap.put("Arkansas", "Little Rock");
        stateCapitalMap.put("California", "Sacramento");
        stateCapitalMap.put("Colorado", "Denver");
        stateCapitalMap.put("Connecticut", "Hartford");
        stateCapitalMap.put("Delaware", "Dover");
        stateCapitalMap.put("Florida", "Tallahassee");
        stateCapitalMap.put("Georgia", "Atlanta");
        stateCapitalMap.put("Hawaii", "Honolulu");
        stateCapitalMap.put("Idaho", "Boise");
        stateCapitalMap.put("Illinois", "Springfield");
        stateCapitalMap.put("Indiana", "Indianapolis");
        stateCapitalMap.put("Iowa", "Des Moines");
        stateCapitalMap.put("Kansas", "Topeka");
        stateCapitalMap.put("Kentucky", "Frankfort");
        stateCapitalMap.put("Louisiana", "Baton Rouge");
        stateCapitalMap.put("Maine", "Augusta");
        stateCapitalMap.put("Maryland", "Annapolis");
        stateCapitalMap.put("Massachusetts", "Boston");
        stateCapitalMap.put("Michigan", "Lansing");
        stateCapitalMap.put("Minnesota", "Saint Paul");
        stateCapitalMap.put("Mississippi", "Jackson");
        stateCapitalMap.put("Missouri", "Jefferson City");
        stateCapitalMap.put("Montana", "Helena");
        stateCapitalMap.put("Nebraska", "Lincoln");
        stateCapitalMap.put("Nevada", "Carson City");
        stateCapitalMap.put("New Hampshire", "Concord");
        stateCapitalMap.put("New Jersey", "Trenton");
        stateCapitalMap.put("New Mexico", "Santa Fe");
        stateCapitalMap.put("New York", "Albany");
        stateCapitalMap.put("North Carolina", "Raleigh");
        stateCapitalMap.put("North Dakota", "Bismarck");
        stateCapitalMap.put("Ohio", "Columbus");
        stateCapitalMap.put("Oklahoma", "Oklahoma City");
        stateCapitalMap.put("Oregon", "Salem");
        stateCapitalMap.put("Pennsylvania", "Harrisburg");
        stateCapitalMap.put("Rhode Island", "Providence");
        stateCapitalMap.put("South Carolina", "Columbia");
        stateCapitalMap.put("South Dakota", "Pierre");
        stateCapitalMap.put("Tennessee", "Nashville");
        stateCapitalMap.put("Texas", "Austin");
        stateCapitalMap.put("Utah", "Salt Lake City");
        stateCapitalMap.put("Vermont", "Montpelier");
        stateCapitalMap.put("Virginia", "Richmond");
        stateCapitalMap.put("Washington", "Olympia");
        stateCapitalMap.put("West Virginia", "Charleston");
        stateCapitalMap.put("Wisconsin", "Madison");
        stateCapitalMap.put("Wyoming", "Cheyenne");

        return stateCapitalMap;
    }
}
