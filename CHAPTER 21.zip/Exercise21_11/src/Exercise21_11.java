import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Exercise21_11 extends Application {
    @SuppressWarnings("unchecked")
    private Map<String, Integer>[] mapForBoy = new HashMap[10];
    @SuppressWarnings("unchecked")
    private Map<String, Integer>[] mapForGirl = new HashMap[10];

    private Button btFindRanking = new Button("Find Ranking");
    private ComboBox<Integer> cboYear = new ComboBox<>();
    private ComboBox<String> cboGender = new ComboBox<>();
    private TextField tfName = new TextField();
    private Label lblResult = new Label();

    @Override
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.add(new Label("Select a year:"), 0, 0);
        gridPane.add(new Label("Boy or girl?"), 0, 1);
        gridPane.add(new Label("Enter a name:"), 0, 2);
        gridPane.add(cboYear, 1, 0);
        gridPane.add(cboGender, 1, 1);
        gridPane.add(tfName, 1, 2);
        gridPane.add(btFindRanking, 1, 3);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(5);
        gridPane.setVgap(5);

        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(gridPane);
        borderPane.setBottom(lblResult);
        BorderPane.setAlignment(lblResult, Pos.CENTER);

        Scene scene = new Scene(borderPane, 370, 160);
        primaryStage.setTitle("Exercise21_11");
        primaryStage.setScene(scene);
        primaryStage.show();

        for (int year = 2001; year <= 2010; year++) {
            cboYear.getItems().add(year);
        }
        cboYear.setValue(2001);

        cboGender.getItems().addAll("Male", "Female");
        cboGender.setValue("Male");

        loadData();

        btFindRanking.setOnAction(e -> findRanking());
    }

    // Method to load data from URLs
    private void loadData() {
        for (int year = 2001; year <= 2010; year++) {
            try {
                URL url = new URL("http://liveexample.pearsoncmg.com/data/babynamesranking" + year + ".txt");
                Scanner scanner = new Scanner(url.openStream());
                mapForBoy[year - 2001] = new HashMap<>();
                mapForGirl[year - 2001] = new HashMap<>();
                while (scanner.hasNextLine()) {
                    String[] tokens = scanner.nextLine().split("\\s+");
                    mapForBoy[year - 2001].put(tokens[1], Integer.parseInt(tokens[0]));
                    mapForGirl[year - 2001].put(tokens[3], Integer.parseInt(tokens[0]));
                }
                scanner.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to find and display the ranking
    private void findRanking() {
        int year = cboYear.getValue();
        String gender = cboGender.getValue();
        String name = tfName.getText();
        int ranking = -1;

        if (gender.equals("Male")) {
            if (mapForBoy[year - 2001].containsKey(name)) {
                ranking = mapForBoy[year - 2001].get(name);
            }
        } else {
            if (mapForGirl[year - 2001].containsKey(name)) {
                ranking = mapForGirl[year - 2001].get(name);
            }
        }

        if (ranking != -1) {
            lblResult.setText(name + " is ranked #" + ranking + " in year " + year);
        } else {
            lblResult.setText(name + " is not ranked in the top 1000 for year " + year);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
