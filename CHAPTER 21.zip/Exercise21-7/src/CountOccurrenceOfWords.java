import java.util.*;

public class CountOccurrenceOfWords {
    public static void main(String[] args) {
    	
        String text = "Good morning. Have a good class. " +
                "Have a good visit. Have fun!";

        // Create a HashMap to hold words as key and count as value
        Map<String, Integer> map = new HashMap<>();

        String[] words = text.split("[\\s+\\p{P}]");
        for (String word : words) {
            String key = word.toLowerCase();

            if (key.length() > 0) {
                map.put(key, map.getOrDefault(key, 0) + 1);
            }
        }

        // Create a list to hold WordOccurrence objects
        List<WordOccurrence> occurrences = new ArrayList<>();
        map.forEach((word, count) -> occurrences.add(new WordOccurrence(word, count)));

        // Sort the list based on occurrence counts and then alphabetically
        Collections.sort(occurrences, Comparator.comparing(WordOccurrence::getCount)
                                                .thenComparing(WordOccurrence::getWord));

        occurrences.forEach(occurrence -> System.out.println(occurrence.word + "\t" + occurrence.count));
    }
}

class WordOccurrence {
    String word;
    int count;

    WordOccurrence(String word, int count) {
        this.word = word;
        this.count = count;
    }

    public String getWord() {
        return word;
    }

    public int getCount() {
        return count;
    }
}
