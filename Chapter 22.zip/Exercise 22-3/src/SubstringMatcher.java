// Joshua X Mechem

/*Knuth-Morris-Pratt (KMP)
 * Longest Prefix Suffix (LPS)
 * m = length of s2
 * n = length of s1
 * O(m+n)
 * Highly effcient for string matching by avoiding redundant comparisons and effectively handling cases with repeating sub-patterns.
 */

import java.util.Scanner; 

public class SubstringMatcher {


    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter a string s1: ");
        String s1 = input.nextLine();
        System.out.print("Enter a string s2: ");
        String s2 = input.nextLine();

        int startIndex = findSubstringKMP(s1, s2);
        if (startIndex >= 0) {
            System.out.println("Matched at index " + startIndex);
        } else {
            System.out.println(s2 + " is not a substring of " + s1);
        }
        
        input.close();
    }

    public static int findSubstringKMP(String s1, String s2) {
        if (s2.isEmpty()) return 0; 
        if (s1.length() < s2.length()) return -1;

        int[] lps = computeLPSArray(s2);
        int i = 0;
        int j = 0;
        while (i < s1.length()) {
            if (s1.charAt(i) == s2.charAt(j)) {
                i++;
                j++;
            }
            if (j == s2.length()) {
                return i - j;
            } else if (i < s1.length() && s1.charAt(i) != s2.charAt(j)) {
                if (j != 0) {
                    j = lps[j - 1];
                } else {
                    i = i + 1;
                }
            }
        }
        return -1;
    }

    private static int[] computeLPSArray(String pattern) {
        int[] lps = new int[pattern.length()];
        int length = 0;
        int i = 1;
        lps[0] = 0;

        while (i < pattern.length()) {
            if (pattern.charAt(i) == pattern.charAt(length)) {
                length++;
                lps[i] = length;
                i++;
            } else {
                if (length != 0) {
                    length = lps[length - 1];
                } else {
                    lps[i] = length;
                    i++;
                }
            }
        }
        return lps;
    }
}