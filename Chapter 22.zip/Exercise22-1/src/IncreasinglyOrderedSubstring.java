// Joshua X Mechem
// Date: 27/03/2024
/* The findLongestIncreasingSubstring method in the JavaFX application iterates through the input string exactly once,
 *  making its overall time complexity O(n), where n is the length of the input string.
 *  It performs constant-time operations within a loop, including character comparison and substring concatenation, 
 *  to identify the longest increasingly ordered substring.
 *  For practical purposes and average-case scenarios, the method is efficient,
 *   although using StringBuilder for concatenation could optimize performance for very large strings.
 */
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.TextInputDialog;
import javafx.scene.text.Text;
import javafx.scene.layout.StackPane;

public class IncreasinglyOrderedSubstring extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        TextInputDialog textInputDialog = new TextInputDialog();
        textInputDialog.setTitle("Input Dialog");
        textInputDialog.setHeaderText("Find the Longest Increasingly Ordered Substring");
        textInputDialog.setContentText("Please enter a string:");

        // Process user input
        String result = textInputDialog.showAndWait().map(inputString -> findLongestIncreasingSubstring(inputString)).orElse("");

        // Display result using JavaFX
        Text text = new Text(result);
        StackPane root = new StackPane();
        root.getChildren().add(text);

        Scene scene = new Scene(root, 300, 200);
        primaryStage.setTitle("Maximum Consecutive Increasingly Ordered Substring");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public String findLongestIncreasingSubstring(String input) {
        if (input == null || input.isEmpty()) return "";
        String maxSubstring = "", currentSubstring = "" + input.charAt(0);

        for (int i = 1; i < input.length(); i++) {
            if (input.charAt(i) > input.charAt(i - 1)) {
                currentSubstring += input.charAt(i);
            } else {
                if (currentSubstring.length() > maxSubstring.length()) {
                    maxSubstring = currentSubstring;
                }
                currentSubstring = "" + input.charAt(i);
            }
        }

        if (currentSubstring.length() > maxSubstring.length()) {
            maxSubstring = currentSubstring;
        }

        return maxSubstring;
    }
}
/* Improvements that can be made:
 * I have Duplicate code in the method findLongestIncreasingSubstring.
 * Could cheack handling of null and empty string.
 * Could add comments.
 */
