import java.util.AbstractSequentialList;
import java.util.ListIterator;

class TwoWayLinkedList<E> extends AbstractSequentialList<E> {
	
    private Node<E> head, tail;
    private int size;

    /** Create a default list */
    public TwoWayLinkedList() {
    }

    /** Create a list from an array of objects */
    public TwoWayLinkedList(E[] objects) {
        for (E e : objects)
            add(e);
    }

    /** Return the head element in the list */
    public E getFirst() {
        if (size == 0) {
            return null;
        } else {
            return head.element;
        }
    }

    /** Return the last element in the list */
    public E getLast() {
        if (size == 0) {
            return null;
        } else {
            return tail.element;
        }
    }

    /** Add an element to the beginning of the list */
    public void addFirst(E e) {
        Node<E> newNode = new Node<E>(e); // Create a new node
        newNode.next = head; // link the new node with the head
        if (head != null) {
            head.previous = newNode;
        }
        head = newNode; // head points to the new node
        size++; // Increase list size

        if (tail == null) // the new node is the only node in list
            tail = head;
    }

    /** Add an element to the end of the list */
    public void addLast(E e) {
        Node<E> newNode = new Node<E>(e); // Create a new for element e
        newNode.previous = tail;
        if (tail != null) {
            tail.next = newNode;
        }
        tail = newNode;
        size++;

        if (head == null)
            head = tail;
    }

    /**
     * Add a new element at the specified index in this list The index of the head
     * element is 0
     */
    public void add(int index, E e) {
        if (index == 0) {
            addFirst(e);
        } else if (index >= size) {
            addLast(e);
        } else {
            Node<E> current = head;
            for (int i = 1; i < index; i++) {
                current = current.next;
            }
            Node<E> temp = current.next;
            current.next = new Node<E>(e);
            current.next.previous = current; // Linking previous node
            current.next.next = temp;
            temp.previous = current.next; // Linking next node
            size++;
        }
    }

    /**
     * Remove the head node and return the object that is contained in the removed
     * node.
     */
    public E removeFirst() {
        if (size == 0) {
            return null;
        } else {
            Node<E> temp = head;
            head = head.next;
            size--;
            if (head == null) {
                tail = null;
            }
            return temp.element;
        }
    }

    /**
     * Remove the last node and return the object that is contained in the removed
     * node.
     */
    public E removeLast() {
        if (size == 0) {
            return null;
        } else if (size == 1) {
            Node<E> temp = head;
            head = tail = null;
            size = 0;
            return temp.element;
        } else {
            Node<E> temp = tail;
            tail = tail.previous;
            tail.next = null;
            size--;
            return temp.element;
        }
    }

    /**
     * Remove the element at the specified position in this list. Return the element
     * that was removed from the list.
     */
    public E remove(int index) {
        if (index < 0 || index >= size) {
            return null;
        } else if (index == 0) {
            return removeFirst();
        } else if (index == size - 1) {
            return removeLast();
        } else {
            Node<E> previous = head;

            for (int i = 1; i < index; i++) {
                previous = previous.next;
            }

            Node<E> current = previous.next;
            previous.next = current.next;
            current.next.previous = previous; // For a two-way linked list
            size--;
            return current.element;
        }
    }
    
    @Override
    public int size() {
        return size;
    }

    @Override
    public ListIterator<E> listIterator(int index) {
        return new LinkedListIterator(index);
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("[");

        Node<E> current = head;
        for (int i = 0; i < size; i++) {
            result.append(current.element);
            current = current.next;
            if (current != null) {
                result.append(", "); // Separate two elements with a comma
            } else {
                result.append("]"); // Insert the closing ] in the string
            }
        }

        return result.toString();
    }

    /** Clear the list */
    public void clear() {
        head = tail = null;
    }

    /** Return true if this list contains the element o */
    public boolean contains(Object e) {
        System.out.println("Implementation left as an exercise");
        return true;
    }

    /** Return the element from this list at the specified index */
    public E get(int index) {
        System.out.println("Implementation left as an exercise");
        return null;
    }

    /**
     * Return the index of the head matching element in this list. Return -1 if no
     * match.
     */
    public int indexOf(Object e) {
        System.out.println("Implementation left as an exercise");
        return 0;
    }

    /**
     * Return the index of the last matching element in this list Return -1 if no
     * match.
     */
    public int lastIndexOf(Object e) {
        System.out.println("Implementation left as an exercise");
        return 0;
    }

    /**
     * Replace the element at the specified position in this list with the specified
     * element.
     */
    public E set(int index, E e) {
        System.out.println("Implementation left as an exercise");
        return null;
    }

    /** Override the iterator method defined in Iterable */
    public java.util.ListIterator<E> iterator() {
        return new LinkedListIterator();
    }

    public class Node<T> {
        T element;
        Node<T> next;
        Node<T> previous;

        public Node(T o) {
            element = o;
        }
    }

    private class LinkedListIterator implements ListIterator<E> {
        private Node<E> current = head; // Current index
        private int index = 0;

        public LinkedListIterator() {
        }

        public LinkedListIterator(int index) {
            if (index < 0 || index > size) {
                throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
            }

            for (int i = 0; i < index; i++) {
            	current=current.next;
            }

            this.index = index;
        }

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public E next() {
            if (!hasNext()) {
                throw new java.util.NoSuchElementException();
            }
            E element = current.element;
            current = current.next;
            index++;
            return element;
        }

        @Override
        public boolean hasPrevious() {
            return current != null && current.previous != null;
        }

        @Override
        public E previous() {
            if (!hasPrevious()) {
                throw new java.util.NoSuchElementException();
            }
            current = current.previous;
            index--;
            return current.element;
        }

        @Override
        public int nextIndex() {
            if (!hasNext()) {
                return size;
            }
            return index;
        }

        @Override
        public int previousIndex() {
            if (!hasPrevious()) {
                return -1;
            }
            return index - 1;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("remove");
        }

        @Override
        public void set(E e) {
            throw new UnsupportedOperationException("set");
        }

        @Override
        public void add(E e) {
            throw new UnsupportedOperationException("add");
        }
    }
}
