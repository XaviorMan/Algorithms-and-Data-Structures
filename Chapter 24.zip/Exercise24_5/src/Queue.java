

class GenericQueue<T> {
    private Object[] elements;
    private int front;
    private int rear;
    private int capacity;

    // Constructor
    public GenericQueue(int capacity) {
        this.capacity = capacity;
        elements = new Object[capacity];
        front = -1;
        rear = -1;
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return front == -1;
    }

    // Method to check if the queue is full
    public boolean isFull() {
        return rear == capacity -1;
    }

    // Method to add an element to the queue
    public String enqueue(T item) {
        if (isFull()) {      
            return "Queue is full. Connot enqueue. ";
        }
        if (front == -1) {
        	front = 0;
        }
        rear++;
        elements[rear] = item;
        return item + "enqueued into the queue";
    }
    
    // Method to remove an element from the queue
    @SuppressWarnings("unchecked")
    public String dequeue() {
        if (isEmpty()) {
           return "Queue is empty. Cannot dequeue."; 
        }
        T item = (T) elements[front];
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front++;
        }
        return item + " dequeued from the queue";
    }

    }