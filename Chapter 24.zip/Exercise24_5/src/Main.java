//Joshua X Mechem
//Date: 03/21/2024

public class Main {
    public static void main(String[] args) {
    	
        GenericQueue<Integer> queue = new GenericQueue<>(5);

        // Enqueueing elements
        System.out.println("Adding elements to the queue:");
        for (int i = 1; i <= 5; i++) {
            int element = i * 10;
            System.out.println(queue.enqueue(element));
        }

        // Dequeueing elements
        System.out.println("\nRemoving elements from the queue:");
        while (!queue.isEmpty()) {
            System.out.println(queue.dequeue());
        }

        // Trying to dequeue from an empty queue
        System.out.println("\nTrying to dequeue from an empty queue:");
        System.out.println(queue.dequeue());
    }
}
